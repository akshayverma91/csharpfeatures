using Csharp10Features.Framework;

namespace Csharp10Features.ExtendedPropertyPattern;


public class ExtendedPropertyPattern
{
    // old
    public static string CallExtendedPropertyPatternOld(Framework framework) => framework switch
    {
        {
            { CodingLanguage:  { Name: "C#" } } => "C Sharp",
            _ => "Unknow language"
        };
    }

    // new way
    public static string CallExtendedPropertyPatternNew(Framework framework) => framework switch
    {
        {
           { CodingLanguage.Name = "C" } => "C Sharp",
            _ => "Unknow language"
        };
    }
    
}