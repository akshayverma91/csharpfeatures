using Csharp10Features.Framework;
using Csharp10Features.CodingLanguage;

namespace Csharp10Features.RecordStructure;


public class RecordStructure
{
    public void CallRecordStructure()
    {
        var framework = new Framework
        {
            Name = "Csharp10Features",
            Version = "1.0.0",
            CodingLanguage = new CodingLanguage { Names = "C#" }
        };

        return JsonSerializer.Serialize(framework);
    }
}
