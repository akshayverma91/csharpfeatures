namespace Csharp10Features.CodingLanguage;


// older way
// public class CodingLanguage
// {
//     public string Name { get; set; }
// }


// new way
public readonly record struct CodingLanguage(string Name);