// this is File Scope Namespace feature
namespace Csharp10Features.FileScopedNamespace;


internal class Test1
{
    public int ID { get; set; }
    public string Name { get; set; }
}