﻿// See https://aka.ms/new-console-template for more information

public class Program
{
    static void Main(string[] args)
    {
        var Names = new[] { "Test1", "Test2", "Test3", "Test4", "Test5" };
        var serializedNames = JsonSerializer.Serialize(Names);

        WriteLine("C# 10 Features");

        WriteLine(Names); // this will return type 'System.String[]'
        WriteLine(serializedNames);
    }
}
