namespace Csharp10Features.Framework;
using Csharp10Features.CodingLanguage;


// older way
// public class Framework
// {
//     public string Name { get; set; }
//     public int Version { get; set; }
//     public CodingLanguage CodingLanguage { get; set; }
// }

// new way
public readonly record struct Framework(string Name, int Version, CodingLanguage CodingLanguage);