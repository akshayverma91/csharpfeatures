namespace Csharp10Features.NullException;

public class NullExceptionClass
{
    public void CallNullExceptionMethod()
    {
        string TestNullFeature = null;

        // older way
        if(TestNullFeature == null)
        {
            throw new ArgumentException(nameof(TestNullFeature));
        }

        //new way
        throw new ArgummentNullException("TestNullFeature", nameof(TestNullFeature));
    }

}
