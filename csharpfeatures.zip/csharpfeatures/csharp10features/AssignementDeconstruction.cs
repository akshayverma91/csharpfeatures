//older version

//Initialization
(int x, int y) => { return (10, 12);  };

//assignment
int x1 = 0;
int x2 = 0;
(x1, x2) => { return (10, 20); };


// new way
int x = 0;
//int y = 0; no need as we declare in below statement directly
(x, int y) => { return (10, 20); };
