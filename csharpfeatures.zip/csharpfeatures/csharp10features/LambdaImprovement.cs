namespace Csharp10Features.LambdaImprovement;
using Csharp10Features.Framework;
using Csharp10Features.CodingLanguage;
using  static System.Console; 

public class LambdaImprovement
{
    public void CallLambdaImprovement()
    {
        // older feature
        Func<string> helloword = () => "Hello World";
        //new feature
        var helloword = () => "Hello World";

        var testReturn = () =>  { return "test"; };
    }
}