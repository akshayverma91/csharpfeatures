﻿using Csharp12Features.PrimaryConstructor;

// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");

var nameItemObj = new NameItem("akshay");

Console.WriteLine(nameItemObj.Name);