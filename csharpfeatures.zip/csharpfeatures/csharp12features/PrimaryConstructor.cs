namespace Csharp12Features.PrimaryConstructor;
public class NameItem(string name)
{
    public string Name => name;
}

