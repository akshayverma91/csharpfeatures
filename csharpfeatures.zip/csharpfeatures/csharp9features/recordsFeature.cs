// https://learn.microsoft.com/en-us/dotnet/csharp/language-reference/builtin-types/record
